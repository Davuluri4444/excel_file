def add(a,b,c,d):
    return a+b+c+d

def append1(i):
    list=[]
    list.append(i)
    return list


